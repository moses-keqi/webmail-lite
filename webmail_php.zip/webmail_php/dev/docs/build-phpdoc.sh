#!/bin/bash

echo "Generate WEB API reference"
./phpdoc.phar --template="templates/afterlogic"