<?php

class Methods {}
